ionic-service-analytics
=======================

Ionic Analytics Service. See the official docs here: http://docs.ionic.io/services/analytics/
