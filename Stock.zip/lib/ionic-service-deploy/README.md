ionic-service-deploy
====================

App deploy service for Ionic. Official docs: http://docs.ionic.io/deploy/
